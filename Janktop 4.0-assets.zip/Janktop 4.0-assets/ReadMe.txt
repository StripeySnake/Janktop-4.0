Hi!
Since you've downloaded these files, I can assume you have some sort of interest in putting together a Janktop.
Here are a couple useful tidbits of information surrounding these files:

In the STL folder, you'll find that the Palmrest and bottom cover have both .stl and .stp versions. These two parts
are ment to be manufactured via sheet cutting rather than 3D printing, and many sites will only take STEP files
for sheet cutting, rather than .stl.

The current Janktop chassis is made up of 20 3d printed parts, and 2 sheet cut ones. All printed parts should be 
printed once, exept for the front and back foot, which should each be printed twice per chassis built.

The Arduino file in this folder can be uploaded to a Teensy 4.0 Based Microcontroller using Frank Adam's USB
Laptop keyboard controller circuit board. All you need to do is get the board, soulder the teensy, and upload this
script to it. (the top right 4 macro keys don't do anything currently, and volume hotkeys are inverted. I'll fix it
someday. Other than that, the script works perfectly and the keyboard is indistinguishible from a normal one)

The default Janktop 4.0 Chassis is designed around and M17x r3/4 display, correlating inverter board for the 60hz 
panel, alphacool 40mm x flow triple radiators, and the alienware 17 r1 keyboard. If you would like to change these
components, look at my "alternates" repo. If you would like a new alternate to be designed, either contact me with 
detailed dimensions of the component it should be compatible, or design it yourself and send it to me. If you 
design one, you will be credited alongside the file if you choose to send it in to add to the alternates repo.
There is not monetary benifit to this, it's just a helpful thing to do.

More info on this project can be found on the Janktop Release thread on NotebookTalk.

Good luck,
   -StripeySnake